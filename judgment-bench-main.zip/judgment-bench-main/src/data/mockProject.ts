export interface Assumption {
  id: string;
  text: string;
  status: "proposed" | "validated" | "superseded";
  sources: { label: string; file: string }[];
}

export interface Risk {
  id: string;
  description: string;
  strategy: "primary" | "alternative";
  tradeoff: string;
}

export interface ChatMessage {
  id: string;
  role: "system" | "user";
  text: string;
  citations?: { label: string; file: string }[];
  timestamp: string;
}

export interface ProjectFile {
  id: string;
  name: string;
  folder: string;
  content: string;
  type: "pdf" | "docx" | "xlsx" | "txt";
}

export const mockProject = {
  name: "Bjørvika Cultural Centre",
  type: "Parallelloppdrag" as const,
  status: "In Progress",
  folders: [
    "00_Brief",
    "01_Jury_Criteria",
    "02_Site",
    "03_Budget_&_Fee",
    "04_CVs_Selected",
    "05_Submission_Draft",
    "06_Submission_Final",
    "09_Meetings",
  ],
};

export const mockAssumptions: Assumption[] = [
  {
    id: "a1",
    text: "Maximum building footprint is 4,200 m² based on regulatory plan §12.3.",
    status: "validated",
    sources: [{ label: "Regulatory Plan §12.3", file: "00_Brief/regulatory_plan.pdf" }],
  },
  {
    id: "a2",
    text: "Jury will prioritize urban integration over formal expression based on criteria weighting.",
    status: "proposed",
    sources: [
      { label: "Jury Criteria Doc", file: "01_Jury_Criteria/criteria_matrix.pdf" },
      { label: "Competition Brief p.14", file: "00_Brief/competition_brief.pdf" },
    ],
  },
  {
    id: "a3",
    text: "Fee ceiling is 8% of construction cost based on comparable parallelloppdrag.",
    status: "proposed",
    sources: [{ label: "Fee Analysis", file: "03_Budget_&_Fee/fee_benchmark.xlsx" }],
  },
];

export const mockDecision = {
  goNoGo: "Go" as const,
  strategy: [
    "Pursue with urban integration as primary narrative.",
    "Allocate 60% of effort to site response, 40% to programmatic innovation.",
    "Fee negotiation ceiling: 8.5% with contingency at 7%.",
  ],
  economicStance: "Conservative. Budget exposure limited to 180,000 NOK pre-submission.",
};

export const mockRisks: Risk[] = [
  {
    id: "r1",
    description: "Jury composition includes two members with documented preference for parametric form.",
    strategy: "primary",
    tradeoff: "Urban integration narrative may underperform if jury weighs formal ambition higher than stated.",
  },
  {
    id: "r2",
    description: "Shift narrative to emphasize formal innovation while maintaining site logic.",
    strategy: "alternative",
    tradeoff: "Requires additional 40 hours of design development. Increases budget exposure to 220,000 NOK.",
  },
];

export const mockChat: ChatMessage[] = [
  {
    id: "c1",
    role: "user",
    text: "What is the maximum height restriction on the site?",
    timestamp: "14:23",
  },
  {
    id: "c2",
    role: "system",
    text: "The regulatory plan specifies a maximum building height of 24 meters measured from average ground level. This is stated in §12.7 of the regulatory plan.",
    citations: [{ label: "Regulatory Plan §12.7", file: "00_Brief/regulatory_plan.pdf" }],
    timestamp: "14:23",
  },
  {
    id: "c3",
    role: "user",
    text: "Is there precedent for exceeding this in the area?",
    timestamp: "14:25",
  },
  {
    id: "c4",
    role: "system",
    text: "No precedent found in submitted references. The adjacent Munch Museum received a dispensation in 2015, but under a different regulatory framework. Applying the same logic here is not advisable without explicit jury guidance.",
    citations: [{ label: "Reference: Munch Museum", file: "02_Site/munch_precedent.pdf" }],
    timestamp: "14:25",
  },
];

export const mockFiles: ProjectFile[] = [
  {
    id: "f1",
    name: "competition_brief.pdf",
    folder: "00_Brief",
    type: "pdf",
    content: "BJØRVIKA CULTURAL CENTRE\nParallelloppdrag\n\nIssued: Oslo Kommune, Plan- og bygningsetaten\nDate: 2024-09-15\n\n1. INTRODUCTION\n\nThe City of Oslo invites qualified architecture offices to participate in a parallelloppdrag for the design of a new cultural centre at Bjørvika.\n\n2. SITE\n\nThe site is located at the intersection of Dronning Eufemias gate and Operagata. Total site area: 6,800 m². Maximum building footprint: 4,200 m².\n\n3. PROGRAMME\n\n- Performance hall: 800 seats\n- Exhibition space: 2,400 m²\n- Workshop spaces: 600 m²\n- Public lobby and circulation: 1,200 m²\n- Administration: 400 m²\n\n4. BUDGET\n\nEstimated construction cost: 890 MNOK (excl. VAT)\nDesign fee: to be negotiated within standard framework.",
  },
  {
    id: "f2",
    name: "criteria_matrix.pdf",
    folder: "01_Jury_Criteria",
    type: "pdf",
    content: "JURY EVALUATION CRITERIA\n\n1. Urban Integration — 35%\n   - Relationship to fjord and existing urban fabric\n   - Public space quality\n   - Pedestrian connectivity\n\n2. Architectural Quality — 25%\n   - Spatial experience\n   - Material strategy\n   - Environmental ambition\n\n3. Programme Resolution — 20%\n   - Functional efficiency\n   - Flexibility\n   - Acoustic performance\n\n4. Feasibility — 20%\n   - Budget alignment\n   - Phasing strategy\n   - Technical realism",
  },
  {
    id: "f3",
    name: "fee_benchmark.xlsx",
    folder: "03_Budget_&_Fee",
    type: "xlsx",
    content: "FEE BENCHMARK ANALYSIS\n\nComparable Projects:\n\n| Project | Year | Construction Cost | Fee % | Fee Amount |\n|---------|------|-------------------|-------|------------|\n| Deichmanske | 2020 | 3,200 MNOK | 7.2% | 230 MNOK |\n| Munch Museum | 2018 | 2,800 MNOK | 8.1% | 227 MNOK |\n| Kulturhuset | 2019 | 450 MNOK | 9.3% | 42 MNOK |\n| NRK Ensjø | 2021 | 1,100 MNOK | 7.8% | 86 MNOK |\n\nRecommended range: 7.5% – 8.5%\nCeiling for negotiation: 8.0%\nContingency floor: 7.0%",
  },
];

export const mockIngestion = {
  total: 47,
  successful: 41,
  partial: 4,
  failed: 2,
  issues: [
    { file: "02_Site/site_photo_scan.pdf", problem: "Scanned PDF. No text layer detected.", suggestion: "Run OCR or request digital version." },
    { file: "02_Site/geotechnical_report.pdf", problem: "Scanned PDF. Partial text extraction.", suggestion: "Pages 12–18 unreadable. Request appendix separately." },
    { file: "04_CVs_Selected/jensen_cv.pdf", problem: "Partial text. Embedded images not processed.", suggestion: "Re-export from source application." },
    { file: "00_Brief/appendix_drawings.dwg", problem: "File format not supported.", suggestion: "Convert to PDF for ingestion." },
    { file: "03_Budget_&_Fee/cost_model_v2.xlsm", problem: "Macro-enabled spreadsheet. Macros ignored.", suggestion: "Export as .xlsx for full compatibility." },
    { file: "09_Meetings/kickoff_notes.docx", problem: "Partial extraction. Track changes not resolved.", suggestion: "Accept all changes and re-upload." },
  ],
};
