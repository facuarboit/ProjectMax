import { useState } from "react";
import { mockFiles, mockProject } from "@/data/mockProject";
import type { ProjectFile } from "@/data/mockProject";

interface TabbedFilePanelProps {
  openFileId?: string | null;
  onCloseFile?: (id: string) => void;
  onStatementClick?: (statement: string) => void;
}

export function TabbedFilePanel({ openFileId, onCloseFile, onStatementClick }: TabbedFilePanelProps) {
  const [activeTab, setActiveTab] = useState<string>("assembly");
  const [openTabs, setOpenTabs] = useState<string[]>([]);

  const fileToOpen = openFileId
    ? mockFiles.find((f) => `${f.folder}/${f.name}` === openFileId || f.id === openFileId)
    : null;

  if (fileToOpen && !openTabs.includes(fileToOpen.id)) {
    setOpenTabs((prev) => [...prev, fileToOpen.id]);
    setActiveTab(fileToOpen.id);
  }

  const handleCloseTab = (id: string) => {
    setOpenTabs((prev) => prev.filter((t) => t !== id));
    if (activeTab === id) setActiveTab("assembly");
    onCloseFile?.(id);
  };

  const activeFile = mockFiles.find((f) => f.id === activeTab);

  return (
    <div className="flex flex-col h-full">
      <div className="flex items-center gap-0 panel-border-bottom overflow-x-auto">
        <button
          onClick={() => setActiveTab("assembly")}
          className={`px-4 py-2.5 text-xs uppercase tracking-wider whitespace-nowrap ${
            activeTab === "assembly" ? "tab-active" : "tab-inactive"
          }`}
        >
          Assembly
        </button>
        {openTabs.map((tabId) => {
          const file = mockFiles.find((f) => f.id === tabId);
          if (!file) return null;
          return (
            <div key={tabId} className="flex items-center">
              <button
                onClick={() => setActiveTab(tabId)}
                className={`px-4 py-2.5 text-xs tracking-wider whitespace-nowrap ${
                  activeTab === tabId ? "tab-active" : "tab-inactive"
                }`}
              >
                {file.name}
              </button>
              <button
                onClick={() => handleCloseTab(tabId)}
                className="px-1 text-xs text-muted-foreground hover:text-foreground"
              >
                ×
              </button>
            </div>
          );
        })}
      </div>

      <div className="flex-1 overflow-y-auto p-5">
        {activeTab === "assembly" ? (
          <AssemblyView onStatementClick={onStatementClick} />
        ) : activeFile ? (
          <FileView file={activeFile} />
        ) : null}
      </div>
    </div>
  );
}

interface AssemblySection {
  title: string;
  content: string;
}

const assemblySections: AssemblySection[] = [
  {
    title: "1. Project Overview",
    content:
      "The Bjørvika Cultural Centre is a parallelloppdrag issued by Oslo Kommune. The site is 6,800 m² at the intersection of Dronning Eufemias gate and Operagata. Programme includes a 800-seat performance hall, 2,400 m² exhibition space, and supporting functions totaling approximately 4,600 m² GFA.",
  },
  {
    title: "2. Strategic Position",
    content:
      "Primary narrative: urban integration. Jury criteria weighting confirms 35% allocation to site response and public space quality. Formal ambition is secondary but non-negligible at 25%.",
  },
  {
    title: "3. Fee & Budget",
    content:
      "Construction cost estimate: 890 MNOK. Recommended fee range: 7.5%–8.5%. Pre-submission budget exposure: 180,000 NOK (conservative).",
  },
];

function AssemblyView({ onStatementClick }: { onStatementClick?: (statement: string) => void }) {
  const [hoveredIdx, setHoveredIdx] = useState<number | null>(null);

  return (
    <div className="space-y-6">
      <div>
        <h2 className="mb-4">Submission Assembly</h2>
        <p className="text-sm text-muted-foreground mb-6">
          Compiled output for {mockProject.name}. Click any section to discuss it.
        </p>
      </div>

      <div className="panel-border p-4">
        <h3 className="text-xs uppercase tracking-wider mb-3">Project Structure</h3>
        <div className="space-y-1">
          {mockProject.folders.map((folder) => (
            <div key={folder} className="flex items-center gap-2 py-1">
              <span className="text-xs text-muted-foreground w-4">—</span>
              <span className="text-sm">{folder}</span>
            </div>
          ))}
        </div>
      </div>

      {assemblySections.map((section, idx) => (
        <button
          key={idx}
          onClick={() => onStatementClick?.(section.content)}
          onMouseEnter={() => setHoveredIdx(idx)}
          onMouseLeave={() => setHoveredIdx(null)}
          className={`panel-border p-4 w-full text-left transition-colors ${
            hoveredIdx === idx ? "bg-secondary" : ""
          }`}
        >
          <h3 className="text-xs uppercase tracking-wider mb-3">{section.title}</h3>
          <p className="text-sm text-muted-foreground leading-relaxed">{section.content}</p>
          {hoveredIdx === idx && (
            <span className="text-xs text-accent mt-2 block">Click to discuss</span>
          )}
        </button>
      ))}
    </div>
  );
}

function FileView({ file }: { file: ProjectFile }) {
  return (
    <div>
      <div className="flex items-center gap-3 mb-4">
        <span className="text-xs text-muted-foreground uppercase tracking-wider">
          {file.folder}
        </span>
        <span className="text-muted-foreground">·</span>
        <span className="text-xs text-muted-foreground uppercase">{file.type}</span>
      </div>
      <h2 className="mb-4">{file.name}</h2>
      <div className="panel-border p-4">
        <pre className="text-sm leading-relaxed whitespace-pre-wrap font-sans">
          {file.content}
        </pre>
      </div>
    </div>
  );
}
