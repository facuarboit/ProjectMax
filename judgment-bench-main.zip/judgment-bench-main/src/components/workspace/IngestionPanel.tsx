import { mockIngestion } from "@/data/mockProject";

interface IngestionPanelProps {
  open: boolean;
  onClose: () => void;
}

export function IngestionPanel({ open, onClose }: IngestionPanelProps) {
  if (!open) return null;

  const { total, successful, partial, failed, issues } = mockIngestion;
  const successPercent = Math.round((successful / total) * 100);
  const partialPercent = Math.round((partial / total) * 100);
  const failedPercent = Math.round((failed / total) * 100);

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center bg-background/80">
      <div className="panel-border bg-background w-full max-w-2xl max-h-[80vh] flex flex-col">
        {/* Header */}
        <div className="flex items-center justify-between px-6 py-4 panel-border-bottom">
          <h2>Ingestion Report</h2>
          <button onClick={onClose} className="text-sm text-muted-foreground hover:text-foreground">
            Close
          </button>
        </div>

        {/* Stats */}
        <div className="px-6 py-4 panel-border-bottom">
          <div className="flex gap-6 mb-4">
            <div>
              <span className="text-2xl font-light">{total}</span>
              <span className="text-xs text-muted-foreground ml-2 uppercase tracking-wider">Total</span>
            </div>
            <div>
              <span className="text-2xl font-light">{successful}</span>
              <span className="text-xs text-muted-foreground ml-2 uppercase tracking-wider">Read</span>
            </div>
            <div>
              <span className="text-2xl font-light">{partial}</span>
              <span className="text-xs text-muted-foreground ml-2 uppercase tracking-wider">Partial</span>
            </div>
            <div>
              <span className="text-2xl font-light">{failed}</span>
              <span className="text-xs text-muted-foreground ml-2 uppercase tracking-wider">Failed</span>
            </div>
          </div>

          {/* Bar */}
          <div className="flex h-2 w-full">
            <div className="bg-foreground" style={{ width: `${successPercent}%` }} />
            <div className="bg-muted-foreground" style={{ width: `${partialPercent}%` }} />
            <div className="bg-destructive" style={{ width: `${failedPercent}%` }} />
          </div>
        </div>

        {/* Issues */}
        <div className="flex-1 overflow-y-auto px-6 py-4">
          <h3 className="text-xs uppercase tracking-wider mb-3">Issues</h3>
          <div className="space-y-3">
            {issues.map((issue, i) => (
              <div key={i} className="panel-border p-3">
                <p className="text-sm font-medium mb-1">{issue.file}</p>
                <p className="text-sm text-muted-foreground mb-1">{issue.problem}</p>
                <p className="text-xs text-accent">Suggestion: {issue.suggestion}</p>
              </div>
            ))}
          </div>
        </div>
      </div>
    </div>
  );
}
