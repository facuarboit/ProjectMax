import { mockProject } from "@/data/mockProject";

interface TopBarProps {
  onExport?: (type: string) => void;
}

export function TopBar({ onExport }: TopBarProps) {
  return (
    <header className="h-12 flex items-center justify-between px-6 panel-border-bottom bg-background">
      <div className="flex items-center gap-6">
        <span className="text-sm tracking-wide uppercase" style={{ fontFamily: "'Helvetica Neue', Helvetica, Arial, sans-serif", fontWeight: 700 }}>ProjectMax</span>
        <span className="text-muted-foreground">·</span>
        <span className="text-sm">{mockProject.name}</span>
        <span className="text-muted-foreground">·</span>
        <span className="text-sm text-muted-foreground">{mockProject.type}</span>
        <span className="text-muted-foreground">·</span>
        <span className="status-badge">{mockProject.status}</span>
      </div>
      <div className="flex items-center gap-4">
        <button
          onClick={() => onExport?.("pdf")}
          className="text-xs uppercase tracking-wider px-3 py-1 bg-foreground text-background hover:bg-foreground/80"
        >
          Export PDF
        </button>
        <button
          onClick={() => onExport?.("xlsx")}
          className="text-xs uppercase tracking-wider px-3 py-1 bg-foreground text-background hover:bg-foreground/80"
        >
          Export XLSX
        </button>
      </div>
    </header>
  );
}
