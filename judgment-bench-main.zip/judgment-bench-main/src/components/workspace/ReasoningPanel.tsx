import { useState } from "react";
import { mockAssumptions, mockDecision, mockRisks } from "@/data/mockProject";
import type { Assumption } from "@/data/mockProject";

type Section = "assumptions" | "decision" | "risks" | "validation";

function statusClass(status: Assumption["status"]) {
  if (status === "validated") return "status-badge status-badge--validated";
  if (status === "superseded") return "status-badge status-badge--superseded";
  return "status-badge status-badge--proposed";
}

interface ReasoningPanelProps {
  onCitationClick?: (file: string) => void;
}

export function ReasoningPanel({ onCitationClick }: ReasoningPanelProps) {
  const [activeSection, setActiveSection] = useState<Section>("assumptions");

  const sections: { key: Section; label: string }[] = [
    { key: "assumptions", label: "Assumptions" },
    { key: "decision", label: "Decision" },
    { key: "risks", label: "Risks" },
    { key: "validation", label: "Validation" },
  ];

  return (
    <div className="flex flex-col h-full">
      {/* Section tabs */}
      <div className="flex gap-0 panel-border-bottom">
        {sections.map((s) => (
          <button
            key={s.key}
            onClick={() => setActiveSection(s.key)}
            className={`px-4 py-2.5 text-xs uppercase tracking-wider ${
              activeSection === s.key ? "tab-active" : "tab-inactive"
            }`}
          >
            {s.label}
          </button>
        ))}
      </div>

      {/* Content */}
      <div className="flex-1 overflow-y-auto p-5">
        {activeSection === "assumptions" && (
          <div className="space-y-4">
            {mockAssumptions.map((a) => (
              <div key={a.id} className="panel-border p-4">
                <div className="flex items-start justify-between gap-3 mb-2">
                  <p className="text-sm leading-relaxed flex-1">{a.text}</p>
                  <span className={statusClass(a.status)}>{a.status}</span>
                </div>
                <div className="flex gap-2 flex-wrap">
                  {a.sources.map((src, i) => (
                    <button
                      key={i}
                      onClick={() => onCitationClick?.(src.file)}
                      className="citation-link text-xs"
                    >
                      {src.label}
                    </button>
                  ))}
                </div>
              </div>
            ))}
          </div>
        )}

        {activeSection === "decision" && (
          <div className="space-y-5">
            <div className="panel-border p-4">
              <div className="flex items-center gap-3 mb-3">
                <h3 className="text-sm">Status</h3>
                <span className="status-badge status-badge--validated">
                  {mockDecision.goNoGo}
                </span>
              </div>
            </div>
            <div className="panel-border p-4">
              <h3 className="text-sm mb-3">Strategy</h3>
              <ul className="space-y-2">
                {mockDecision.strategy.map((s, i) => (
                  <li key={i} className="text-sm text-muted-foreground leading-relaxed">
                    — {s}
                  </li>
                ))}
              </ul>
            </div>
            <div className="panel-border p-4">
              <h3 className="text-sm mb-2">Economic Stance</h3>
              <p className="text-sm text-muted-foreground leading-relaxed">
                {mockDecision.economicStance}
              </p>
            </div>
          </div>
        )}

        {activeSection === "risks" && (
          <div className="space-y-4">
            {mockRisks.map((r) => (
              <div key={r.id} className="panel-border p-4">
                <div className="flex items-center gap-2 mb-2">
                  <span className="status-badge">
                    {r.strategy}
                  </span>
                </div>
                <p className="text-sm mb-2 leading-relaxed">{r.description}</p>
                <p className="text-xs text-muted-foreground leading-relaxed">
                  Trade-off: {r.tradeoff}
                </p>
              </div>
            ))}
          </div>
        )}

        {activeSection === "validation" && (
          <div className="space-y-4">
            <div className="panel-border p-4">
              <h3 className="text-sm mb-3">Pending Validations</h3>
              <div className="space-y-3">
                {mockAssumptions
                  .filter((a) => a.status === "proposed")
                  .map((a) => (
                    <div key={a.id} className="flex items-start justify-between gap-3">
                      <p className="text-sm text-muted-foreground flex-1">{a.text}</p>
                      <button className="text-xs uppercase tracking-wider px-3 py-1 bg-foreground text-background hover:bg-foreground/80 whitespace-nowrap">
                        Validate
                      </button>
                    </div>
                  ))}
              </div>
            </div>
            <div className="panel-border p-4">
              <h3 className="text-sm mb-2">Last Approval</h3>
              <p className="text-sm text-muted-foreground">No approvals recorded yet.</p>
            </div>
          </div>
        )}
      </div>
    </div>
  );
}
