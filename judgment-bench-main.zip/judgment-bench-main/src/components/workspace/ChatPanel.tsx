import { useState, useEffect } from "react";
import { mockChat } from "@/data/mockProject";
import type { ChatMessage } from "@/data/mockProject";

interface ChatPanelProps {
  onCitationClick?: (file: string) => void;
  contextStatement?: string | null;
  onContextConsumed?: () => void;
}

export function ChatPanel({ onCitationClick, contextStatement, onContextConsumed }: ChatPanelProps) {
  const [messages, setMessages] = useState<ChatMessage[]>(mockChat);
  const [input, setInput] = useState("");

  useEffect(() => {
    if (contextStatement) {
      const truncated =
        contextStatement.length > 80 ? contextStatement.slice(0, 80) + "…" : contextStatement;
      setInput(`Discuss: "${truncated}"`);
      onContextConsumed?.();
    }
  }, [contextStatement, onContextConsumed]);

  const handleSend = () => {
    if (!input.trim()) return;
    const newMsg: ChatMessage = {
      id: `msg-${Date.now()}`,
      role: "user",
      text: input,
      timestamp: new Date().toLocaleTimeString([], { hour: "2-digit", minute: "2-digit" }),
    };
    setMessages((prev) => [...prev, newMsg]);
    setInput("");

    // Mock system response
    setTimeout(() => {
      const reply: ChatMessage = {
        id: `msg-${Date.now() + 1}`,
        role: "system",
        text: "Acknowledged. This statement references validated project data. Specify the aspect you want to examine: scope, evidence basis, or risk implications.",
        timestamp: new Date().toLocaleTimeString([], { hour: "2-digit", minute: "2-digit" }),
      };
      setMessages((prev) => [...prev, reply]);
    }, 600);
  };

  return (
    <div className="flex flex-col h-full">
      <div className="flex-1 overflow-y-auto px-5 py-3 space-y-3">
        {messages.map((msg) => (
          <div key={msg.id} className="flex gap-3">
            <span className="text-xs text-muted-foreground w-10 pt-0.5 shrink-0">
              {msg.timestamp}
            </span>
            <div className="flex-1">
              <span className="text-xs uppercase tracking-wider text-muted-foreground mr-2">
                {msg.role === "system" ? "System" : "You"}
              </span>
              <span className="text-sm leading-relaxed">{msg.text}</span>
              {msg.citations && msg.citations.length > 0 && (
                <div className="mt-1 flex gap-2 flex-wrap">
                  {msg.citations.map((c, i) => (
                    <button
                      key={i}
                      onClick={() => onCitationClick?.(c.file)}
                      className="citation-link text-xs"
                    >
                      {c.label}
                    </button>
                  ))}
                </div>
              )}
            </div>
          </div>
        ))}
      </div>

      <div className="panel-border-top px-5 py-3 flex gap-3">
        <input
          type="text"
          value={input}
          onChange={(e) => setInput(e.target.value)}
          onKeyDown={(e) => e.key === "Enter" && handleSend()}
          placeholder="Ask a question. Cite evidence."
          className="flex-1 text-sm bg-transparent outline-none placeholder:text-muted-foreground"
        />
        <button
          onClick={handleSend}
          className="text-xs uppercase tracking-wider px-3 py-1 bg-foreground text-background hover:bg-foreground/80"
        >
          Send
        </button>
      </div>
    </div>
  );
}
