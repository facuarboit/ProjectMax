import { useState } from "react";
import { TopBar } from "@/components/workspace/TopBar";
import { ReasoningPanel } from "@/components/workspace/ReasoningPanel";
import { TabbedFilePanel } from "@/components/workspace/TabbedFilePanel";
import { ChatPanel } from "@/components/workspace/ChatPanel";
import { IngestionPanel } from "@/components/workspace/IngestionPanel";

export default function Index() {
  const [openFileId, setOpenFileId] = useState<string | null>(null);
  const [ingestionOpen, setIngestionOpen] = useState(false);
  const [chatContext, setChatContext] = useState<string | null>(null);

  const handleCitationClick = (file: string) => {
    setOpenFileId(file);
  };

  const handleStatementClick = (statement: string) => {
    setChatContext(statement);
  };

  return (
    <div className="h-screen flex flex-col bg-background">
      <TopBar />

      <div className="px-6 py-2 panel-border-bottom flex items-center justify-between">
        <div className="flex items-center gap-4">
          <span className="text-xs uppercase tracking-wider text-muted-foreground">
            47 files ingested
          </span>
          <span className="text-xs text-muted-foreground">·</span>
          <span className="text-xs text-destructive">2 failures</span>
        </div>
        <button
          onClick={() => setIngestionOpen(true)}
          className="text-xs uppercase tracking-wider text-accent hover:text-foreground"
        >
          View Report
        </button>
      </div>

      <div className="flex-1 flex min-h-0">
        <div className="w-[380px] shrink-0 panel-border-right flex flex-col min-h-0">
          <ReasoningPanel onCitationClick={handleCitationClick} />
        </div>

        <div className="flex-1 flex flex-col min-h-0">
          <div className="flex-1 min-h-0">
            <TabbedFilePanel
              openFileId={openFileId}
              onCloseFile={() => setOpenFileId(null)}
              onStatementClick={handleStatementClick}
            />
          </div>

          <div className="h-[220px] shrink-0 panel-border-top">
            <ChatPanel
              onCitationClick={handleCitationClick}
              contextStatement={chatContext}
              onContextConsumed={() => setChatContext(null)}
            />
          </div>
        </div>
      </div>

      <IngestionPanel open={ingestionOpen} onClose={() => setIngestionOpen(false)} />
    </div>
  );
}
